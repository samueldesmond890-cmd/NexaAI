import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'NexaAI — Your AI Assistant',
  description: 'NexaAI — your personal AI assistant.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
