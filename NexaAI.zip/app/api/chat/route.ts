import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  try {
    const { messages } = await request.json();

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: 'OPENAI_API_KEY is not configured.' }, { status: 500 });
    }

    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: 'Please provide at least one message.' }, { status: 400 });
    }

    const input = messages
      .filter((m: any) => m && (m.role === 'user' || m.role === 'assistant'))
      .map((m: any) => ({
        role: m.role,
        content: String(m.content ?? '').slice(0, 12000),
      }));

    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
        instructions: 'You are a helpful, clear and friendly AI assistant. Answer accurately and do not pretend to know things you do not know.',
        input,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return NextResponse.json(
        { error: data?.error?.message || 'The AI provider returned an error.' },
        { status: response.status }
      );
    }

    return NextResponse.json({ message: data.output_text || 'I could not generate a response.' });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Something went wrong while contacting the AI.' }, { status: 500 });
  }
}
