'use client';

import { FormEvent, useEffect, useRef, useState } from 'react';

type Message = { role: 'user' | 'assistant'; content: string };

const starterPrompts = [
  'Explain something to me in simple English',
  'Help me write a professional message',
  'Give me ideas for a business',
];

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), [messages, loading]);

  async function sendMessage(text: string) {
    const value = text.trim();
    if (!value || loading) return;
    setInput('');
    setError('');
    const next = [...messages, { role: 'user' as const, content: value }];
    setMessages(next);
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Request failed');
      setMessages([...next, { role: 'assistant', content: data.message }]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong.');
      setMessages(next);
    } finally {
      setLoading(false);
    }
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    void sendMessage(input);
  }

  function newChat() {
    setMessages([]);
    setInput('');
    setError('');
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <button className="newChat" onClick={newChat}>＋ New chat</button>
        <div className="sideSection"><span>Today</span>{messages.length > 0 && <button className="historyItem" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>{messages[0]?.content.slice(0, 28)}{messages[0]?.content.length > 28 ? '…' : ''}</button>}</div>
        <div className="sidebarBottom"><div className="profile"><div className="avatar">AI</div><div><strong>NexaAI</strong><small>Personal assistant</small></div></div></div>
      </aside>

      <section className="chatArea">
        <header className="topbar"><div className="brand"><div className="brandMark">N</div><span>NexaAI</span></div><button className="menuButton" aria-label="More options">•••</button></header>

        <div className="conversation">
          {messages.length === 0 ? (
            <div className="welcome">
              <div className="welcomeIcon">N</div>
              <h1>How can I help you?</h1>
              <p>Your own AI assistant. Ask questions, write messages, brainstorm ideas, or learn something new.</p>
              <div className="prompts">{starterPrompts.map((p) => <button key={p} onClick={() => void sendMessage(p)}>{p}<span>→</span></button>)}</div>
            </div>
          ) : (
            <div className="messages">{messages.map((m, i) => <div key={i} className={`messageRow ${m.role}`}><div className="messageAvatar">{m.role === 'user' ? 'You' : '✦'}</div><div className="bubble"><div className="roleLabel">{m.role === 'user' ? 'You' : 'NexaAI'}</div><div className="content">{m.content}</div></div></div>)}{loading && <div className="messageRow assistant"><div className="messageAvatar">N</div><div className="bubble"><div className="roleLabel">NexaAI</div><div className="typing"><i></i><i></i><i></i></div></div></div>}<div ref={bottomRef}/></div>
          )}
        </div>

        <div className="composerWrap"><form className="composer" onSubmit={submit}><textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(e); } }} placeholder="Message NexaAI…" rows={1} disabled={loading}/><button className="send" type="submit" disabled={!input.trim() || loading} aria-label="Send">↑</button></form><div className="disclaimer">AI can make mistakes. Check important information.</div>{error && <div className="error">{error}</div>}</div>
      </section>
    </main>
  );
}
